"""
Running your first program

"""

print('Welcome to QF635: Market Microstructure & Algorithmic Trading')
print('5 + 3 = {}'.format(5+3))
