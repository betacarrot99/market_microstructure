"""
Define a function to calculate mid from bid and offer prices
"""


def calculate_mid(bid_price: float, offer_price: float) -> float:
    # TODO replace pass with your code
    pass


mid = calculate_mid(100.50, 101.80)
print(mid)
