"""
Lists are used to store multiple items in a single variable.
It is a collection which is ordered and changeable. Allows duplicate members.

We can use a list to store bid and ask prices of an order book
"""

# bid prices
bid_prices = [100, 99, 98]

# TODO add some ask prices
ask_prices = []

# TODO sort ask prices

# TODO get best bid

# TODO get best offer

# TODO compute mid from best bid and offer

# TODO print mid
