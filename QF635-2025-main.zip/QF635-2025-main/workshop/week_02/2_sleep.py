"""
Use a while-loop and time.sleep() function to print an increasing series of number once every 2 seconds.

Reference: https://www.geeksforgeeks.org/sleep-in-python/

"""
import time

number = 1
while True:
    # print the number
    print(number)

    # sleep for 2 seconds
    # TODO

    # increment the number
    # TODO
