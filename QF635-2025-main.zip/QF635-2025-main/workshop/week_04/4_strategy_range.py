"""
Create a range trading strategy

"""