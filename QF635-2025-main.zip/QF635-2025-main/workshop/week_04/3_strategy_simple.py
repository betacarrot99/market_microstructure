"""
Create a simple strategy to buy and sell periodically.

"""


# TODO get api key and secret
def get_credentials():
    pass


# TODO send market order
def send_market_order(key: str, secret: str, symbol: str, quantity: float, side: bool):
    pass


# TODO main loop to buy and sell periodically
if __name__ == '__main__':
    pass
